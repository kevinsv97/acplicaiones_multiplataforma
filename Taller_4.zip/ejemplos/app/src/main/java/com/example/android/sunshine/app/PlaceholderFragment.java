package com.example.android.sunshine.app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PlaceholderFragment extends Fragment {

    ArrayAdapter<String> mForecastAdapter;

    public PlaceholderFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Es necesario definir una información dummy para la prueba, por favor agregue
        String[] data = {
                getString(R.string.monday)+"2017/03/06 - "+getString(R.string.Sunny)+" -14/7",
                getString(R.string.thuesday)+"2017/03/07 - "+getString(R.string.Mist)+" -8/4",
                getString(R.string.wendnesday)+"2017/03/08 - "+getString(R.string.Ranny)+" -5/17",
                getString(R.string.thursday)+"2017/03/09 - "+getString(R.string.cloudy)+" -8/15",
                getString(R.string.friday)+"2017/03/10 - "+getString(R.string.Ranny)+" -7/14",
                getString(R.string.saturday)+"2017/03/11 - "+getString(R.string.Sunny)+" -10/75",
                getString(R.string.sunday)+"2017/03/12 - "+getString(R.string.Ranny)+" -15/15",
                getString(R.string.monday)+"2017/03/13 - "+getString(R.string.Mist)+" -16/10",
                getString(R.string.thuesday)+"2017/03/14 - "+getString(R.string.Sunny)+" -19/25",
                getString(R.string.wendnesday)+"2017/03/15 - "+getString(R.string.cloudy)+" -13/13",
                getString(R.string.thursday)+"2017/03/16 - "+getString(R.string.No_info)+" -19/16",
                getString(R.string.friday)+"2017/03/17 - "+getString(R.string.Mist)+" -15/13",
                getString(R.string.saturday)+"2017/03/18 - "+getString(R.string.Sunny)+" -15/15",
                getString(R.string.sunday)+"2017/03/19 - "+getString(R.string.Ranny)+" -18/17",
                getString(R.string.monday)+"2017/03/20 - "+getString(R.string.Mist)+" -15/18",
                getString(R.string.thuesday)+"2017/03/21 - "+getString(R.string.Sunny)+" -14/20",
                getString(R.string.wendnesday)+"2017/03/22 - "+getString(R.string.cloudy)+" -18/19",
                getString(R.string.thursday)+"2017/03/23 - "+getString(R.string.Mist)+" -19/09",
                getString(R.string.friday)+"2017/03/24 - "+getString(R.string.No_info)+" -20/20",
                getString(R.string.saturday)+"2017/03/25 - "+getString(R.string.Mist)+" -16/25",
                getString(R.string.sunday)+"2017/03/26 - "+getString(R.string.Sunny)+" -14/27",
                getString(R.string.monday)+"2017/03/27 - "+getString(R.string.Mist)+" -17/18",
                getString(R.string.thuesday)+"2017/03/28 - "+getString(R.string.cloudy)+" -14/30",
                getString(R.string.wendnesday)+"2017/03/29 - "+getString(R.string.No_info)+" -13/23",
                getString(R.string.thursday)+"2017/03/30 - "+getString(R.string.Mist)+" -15/45",
                getString(R.string.friday)+"2017/03/31 - "+getString(R.string.Sunny)+" -13/16",
                getString(R.string.saturday)+"2017/04/01 - "+getString(R.string.Mist)+" -15/13",
                getString(R.string.sunday)+"2017/04/02 - "+getString(R.string.No_info)+" -13/17",
                getString(R.string.monday)+"2017/04/03 - "+getString(R.string.cloudy)+" -14/18",
                getString(R.string.thuesday)+"2017/04/04 - "+getString(R.string.Ranny)+" -14/19"

        };
        List<String> weekForecast = new ArrayList<String>(Arrays.asList(data));


        // Now that we have some dummy forecast data, create an ArrayAdapter.
        // The ArrayAdapter will take data from a source (like our dummy forecast) and
        // use it to populate the ListView it's attached to.
        mForecastAdapter =
                new ArrayAdapter<String>(
                        getActivity(), // The current context (this activity)
                        R.layout.list_item_forecast, // The name of the layout ID.
                        R.id.list_item_forecast_textview, // The ID of the textview to populate.
                        weekForecast);

        View rootView = inflater.inflate(R.layout.fragment_main, container, false);

        // Get a reference to the ListView, and attach this adapter to it.
        ListView listView = (ListView) rootView.findViewById(R.id.listview_forecast);
        listView.setAdapter(mForecastAdapter);

        return rootView;
    }
}